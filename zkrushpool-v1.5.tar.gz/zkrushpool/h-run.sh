#!/usr/bin/env bash

cd `dirname $0`

#export LD_LIBRARY_PATH=.

source colors
source h-manifest.conf
source $CUSTOM_CONFIG_FILENAME

ACCOUNT=`grep "CUSTOM_TEMPLATE=" /hive-config/wallet.conf | awk -F '"' '{print $2}' | awk -F '.' '{print $1}'`
MACHINE_NAME=`grep "CUSTOM_TEMPLATE=" /hive-config/wallet.conf | awk -F '"' '{print $2}' | awk -F '.' '{print $2}'`

echo
mkdir -p $CUSTOM_LOG_BASENAME

./aleo-pool-prover --pool $HOST --account $ACCOUNT --worker-name $MACHINE_NAME 2>&1 | tee --append $CUSTOM_LOG_BASENAME.log
