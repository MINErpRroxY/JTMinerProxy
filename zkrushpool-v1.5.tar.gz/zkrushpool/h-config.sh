#!/usr/bin/env bash

cd `dirname $0`

conf=""
conf+="HOST=\"$CUSTOM_URL\""$'\n'

echo "$conf" > $CUSTOM_CONFIG_FILENAME
