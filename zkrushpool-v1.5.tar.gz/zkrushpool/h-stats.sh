#!/usr/bin/env bash

#set -ex

stats_raw=`curl -s --connect-timeout 5 http://127.0.0.1:9988/api`

readarray -t arr < <(echo "$stats_raw" | jq -cr '[.gpu[].proof_rate],.proofrate_total,.params.version,[.gpu[].bus_id]')
hs="${arr[0]}"
khs="${arr[1]}"
version="${arr[2]}"
algo="aleo"
hs_units="hs"
bus_numbers="${arr[3]}"

stats=$(jq -nc --arg algo "$algo" \
               --arg hs_units "$hs_units" \
               --arg ver "$version" \
               --argjson bus_numbers "$bus_numbers" \
               --argjson hs "$hs" \
               '{$hs, $hs_units, $algo, $bus_numbers, $ver}')

echo $khs
echo $stats
